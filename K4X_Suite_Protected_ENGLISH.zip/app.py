
from flask import Flask, render_template, request, redirect, url_for, session
app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for session

PASSWORD = 'kader11000'

@app.before_request
def require_login():
    if request.endpoint != 'login' and 'logged_in' not in session:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form.get('password') == PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('index'))
    return '''
        <form method="post">
            <h2>Enter Password</h2>
            <input type="password" name="password" />
            <input type="submit" value="Login" />
        </form>
    '''


from flask import Flask, render_template, request
from werkzeug.utils import secure_filename


class Channel:
    def __init__(self, name, url):
        self.name = name
        self.url = url

iptv_channels = {
    "Africa": {
        "Egypt": [Channel("Nile News", "https://stream.live.nilenews.tv/stream/1.m3u8"),
                  Channel("ON Live", "https://streaming.on.tv/live/on.m3u8")],
        "Morocco": [Channel("Al Aoula", "https://cdnamd-hls-globecast.akamaized.net/live/ramdisk/al_aoula_inter/hls_snrt/index.m3u8")]
    },
    "Asia": {
        "Saudi Arabia": [Channel("Al Ekhbariya", "https://media.ekh.sa/ekh.m3u8")],
        "UAE": [Channel("Dubai TV", "https://dubaidtv-live.akamaized.net/hls/live/2031066/DubaiTV/index.m3u8")]
    },
    "Europe": {
        "UK": [Channel("BBC World", "https://vs-cdn-sg.bbcworldnews.com/live/bbc.m3u8")],
        "France": [Channel("France 24", "https://static.france24.com/live/F24_EN_LO_HLS/live_web.m3u8")]
    },
    "North America": {
        "USA": [Channel("NASA TV", "https://nasatv-lh.akamaihd.net/i/NASA_101@319270/master.m3u8")],
        "Canada": [Channel("CBC News", "https://cbcnewshdcanada-lh.akamaihd.net/i/cbcnews_hd@377526/master.m3u8")]
    },
    "South America": {
        "Brazil": [Channel("TV Cultura", "https://5f3e9e213c34a.streamlock.net:443/tvcultura/smil:tvcultura.smil/playlist.m3u8")]
    },
    "Oceania": {
        "Australia": [Channel("ABC News Australia", "https://live-hls-web-aje.getaj.net/AJE/01.m3u8")]
    }
}

@app.route('/iptv', methods=['GET', 'POST'])
def iptv():
    continent = request.form.get("continent")
    country_sel = request.form.get("country")
    selected_channel = request.form.get("channel")
    uploaded_channel = request.form.get("uploaded_channel")
    stream_url = uploaded_channel if uploaded_channel else None
    m3u_links = []
    selected_uploaded = uploaded_channel

    if 'm3ufile' in request.files:
        file = request.files['m3ufile']
        if file.filename.endswith('.m3u') or file.filename.endswith('.m3u8'):
            lines = file.read().decode(errors='ignore').splitlines()
            for i in range(len(lines)):
                if lines[i].startswith('#EXTINF'):
                    name = lines[i].split(',')[-1].strip()
                    if i + 1 < len(lines):
                        url = lines[i + 1].strip()
                        m3u_links.append((name, url))

    if continent and country_sel and selected_channel:
        for ch in iptv_channels[continent][country_sel]:
            if ch.name == selected_channel:
                stream_url = ch.url
                break

    return render_template("iptv.html",
                           channels=iptv_channels,
                           continent=continent,
                           country_sel=country_sel,
                           selected_channel=selected_channel,
                           stream_url=stream_url,
                           m3u_links=m3u_links,
                           selected_uploaded=selected_uploaded)

if __name__ == '__main__':
    app.run(debug=True)